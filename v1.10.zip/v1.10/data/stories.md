## Tax ward: ward number
* home
  - utter_intro
  - utter_intro_buttons
* basic_tax_info_b
  - utter_assistance
* flag_yes
  - utter_taxation_details_buttons
* wardtax_based_b
  - action_reset_form_slots
  - action_ward_form
  - form{"name": "action_ward_form"}
  - form{"name": null}
  - utter_ward_expand_buttons
* ward_building_type_b
  - action_wardbtype_form
  - form{"name": "action_wardbtype_form"}
  - form{"name": null}
  - utter_more_ward
* flag_yes
  - action_reset_form_slots
  - action_ward_form
  - form{"name": "action_ward_form"}
  - form{"name": null}
  - utter_ward_expand_buttons
* flag_no
  - utter_cheer_up

# Tax ward: owner details
* ward_owner_b
  - action_wardowner_details
  - utter_more_ward
* flag_yes
  - action_reset_form_slots
  - action_ward_form
  - form{"name": "action_ward_form"}
  - form{"name": null}
  - utter_ward_expand_buttons
* flag_no
  - utter_cheer_up

# Tax based on propid
* propidtax_based_b
  - action_propid_form
  - form{"name": "action_propid_form"}
  - form{"name": null}
  - utter_again_prop_id
* flag_yes
  - action_propid_form
  - form{"name": "action_propid_form"}
  - form{"name": null}
  - utter_again_prop_id
* flag_no
  - utter_cheer_up
  
# tax FAQ: Owner details
* taxfq_based_b
  - utter_tax_related_faq_buttons
* high_tax_owner_b
  - action_owner_details

# tax F&Q: building type ward
* ward_building_type_b
  - action_building_type_form
  - form{"name": "action_building_type_form"}
  - form{"name": null}
  - utter_again_building_type
* flag_yes
  - action_building_type_form
  - form{"name": "action_building_type_form"}
  - form{"name": null}
  - utter_again_building_type
* flag_no
  - utter_cheer_up

# developer support
* dev_support_b
  - contact_dev_form
  - form{"name": "contact_dev_form"}
  - form{"name": null}
  - utter_additional_feedback
* flag_no
  - utter_intro_buttons
* flag_yes
  - contact_dev_form
  - form{"name": "contact_dev_form"}
  - form{"name": null}
  - utter_additional_feedback

* bye
  - utter_cheer_up

# no assistance path tax details
* home
  - utter_intro
  - utter_intro_buttons
* basic_tax_info_b
  - utter_assistance
* flag_no
  - utter_type_querry
* tax_details{"service_type":"TAX","service_cat":"prop_id","property_type":"RESIDENTIAL"}
  - action_basic_tax


# basic tax details
* tax_details{"service_type":"TAX","service_cat":"prop_id","property_type":"RESIDENTIAL"}
  - action_basic_tax
* extend_ward_number
  - action_basic_tax
* extend_property_types
  - action_basic_tax

# Owner details of property ID
* owner_details{"service_cat":"prop_id"}
  - action_owner_info

# Highest or lowest tax owner details
* high_low_tax_owner_general{"hilo":"high", "property_type":"RESIDENTIAL"}
  - action_high_low_tax_owner
* extend_ward_number
  - action_high_low_tax_owner
* extend_property_types
  - action_high_low_tax_owner

# prop_type details
* prop_type_details{"service_cat":"prop_type"}
  - action_property_type_details
* extend_ward_number
  - action_property_type_details

# no assisatance path
* home
  - utter_intro
  - utter_intro_buttons
* basic_tax_info_b
  - utter_assistance
* flag_no
  - utter_type_querry

# no assistance path prop types
* home
  - utter_intro
  - utter_intro_buttons
* basic_tax_info_b
  - utter_assistance
* flag_no
  - utter_type_querry
* prop_type_details{"service_cat":"prop_type"}
  - action_property_type_details




<!-- utter_again_ward_information
flag_yes -->