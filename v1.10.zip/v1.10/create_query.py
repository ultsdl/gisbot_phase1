import pandas as pd 
import numpy as np
from connect import execute_querry


def prop_id_fetch(prop_id):
    q = f"select ownr_nm,ward_nm,bldg_typ,ownr_mob,ownr_house,tax_amnt,tax_annual from knr_full_assets where new_pro_id = '{prop_id}'"
    q = execute_querry(q)
    return q


def ward_tax_fetch(ward_no=None,sub_type='total_tax'):
    if ward_no is not None:
        if sub_type == 'owner':
            q = f"select ownr_nm,ward_nm,bldg_typ,ownr_mob,ownr_house,tax_amnt,tax_annual from knr_full_assets where ward_no = '{ward_no}' order by tax_amnt DESC limit 1"
        elif sub_type == 'total_tax':
            q = f"select ward_no,ward_nm,tax_amnt,tax_annual from knr_full_assets where ward_no = '{ward_no}'"
        q = execute_querry(q)
    else:
        if sub_type == 'owner':
            q = f"select ownr_nm,ward_nm,bldg_typ,ownr_mob,ownr_house,tax_amnt,tax_annual from knr_full_assets order by tax_amnt DESC limit 1"
        q = execute_querry(q)
    return q

def building_details(building_type, ward_no=None):
    if ward_no is None:
        q =  "SELECT tax_amnt,tax_annual from knr_full_assets WHERE bldg_typ ='{}'".format(building_type)
    else:
        q = "SELECT tax_amnt,tax_annual from knr_full_assets WHERE (bldg_typ ='{}' AND ward_no = '{}')".format(building_type, ward_no)
    q = execute_querry(q)
    return q

def basic_tax(prop_type, prop_id, ward_no):
    if prop_type is None and ward_no is not None:
        q = "SELECT tax_amnt,tax_annual from knr_full_assets WHERE ward_no = '{}'".format(ward_no)
        error = 'Invalid ward number'
    elif prop_type is not None and ward_no is None:
        q = "SELECT tax_amnt,tax_annual from knr_full_assets WHERE bldg_typ = '{}'".format(prop_type)
        error = None
    elif prop_type is None and ward_no is None:
        if prop_id is None:
            q = "SELECT tax_amnt,tax_annual from knr_full_assets"
            error = None
        else:
            q = f"select ownr_nm,ward_nm,bldg_typ,ownr_mob,ownr_house,tax_amnt,tax_annual from knr_full_assets where new_pro_id = '{prop_id}'"
            error = 'Invalid property ID'
    else:
        q = "SELECT tax_amnt,tax_annual from knr_full_assets WHERE (ward_no = '{}' AND bldg_typ = '{}')".format(ward_no, prop_type)
        error = 'Invalid ward number'
    q = execute_querry(q)
    return q, error

def high_low(val, prop_type, ward_no):
    status = "DESC" if val=="high" else "ASC"
    if prop_type is None and ward_no is None:
        q = "select ownr_nm,ward_nm,ward_no,bldg_typ,ownr_mob,ownr_house,tax_amnt,tax_annual from knr_full_assets WHERE tax_amnt>=0 order by tax_amnt {} limit 1".format(status)
        error = "Difficult to fetch data. Please try again later"
    elif prop_type is None and ward_no is not None:
        q = "select ownr_nm,ward_nm,ward_no,bldg_typ,ownr_mob,ownr_house,tax_amnt,tax_annual from knr_full_assets WHERE (tax_amnt>=0 and ward_no='{}') order by tax_amnt {} limit 1".format(ward_no,status)
        error = "Invalid ward number"
    elif prop_type is not None and ward_no is None:
        q = "select ownr_nm,ward_nm,ward_no,bldg_typ,ownr_mob,ownr_house,tax_amnt,tax_annual from knr_full_assets WHERE (tax_amnt>=0 and bldg_typ='{}') order by tax_amnt {} limit 1".format(prop_type,status)
        error = "Invalid property type"
    else:
        q = "select ownr_nm,ward_nm,ward_no,bldg_typ,ownr_mob,ownr_house,tax_amnt,tax_annual from knr_full_assets WHERE (tax_amnt>=0 and bldg_typ='{}' and ward_no='{}') order by tax_amnt {} limit 1".format(prop_type,ward_no,status)
        error = "Sorry! Difficult to fetch the information. Kindly make sure the ward number/property type exists in this LSGD"
    try:
        q = execute_querry(q)
        return (q, error)
    except:
        return (None, error)

def property_details(ward_no=None):
    if ward_no is None:
        q = f"SELECT distinct(bldg_typ) from knr_full_assets"
    else:
        q = f"SELECT distinct(bldg_typ) from knr_full_assets WHERE ward_no = {ward_no}"
    q = execute_querry(q)
    return [i for i in q['bldg_typ'].values if i != 'NA']