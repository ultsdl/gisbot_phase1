import numpy as np
import pandas as pd
from os import path
import datetime

def register_complaint(sender, message, response):
    time = datetime.datetime.now()
    if not path.exists("dataset/complaint_box.csv"):
        df = pd.DataFrame([{"Time":time, "Sender_ID":sender, "Quary":message, "Response": response}])
        df.to_csv("dataset/complaint_box.csv", index=False)
    else:
        df = pd.DataFrame([{"Time":time, "Sender_ID":sender, "Quary":message, "Response": response}])
        df.to_csv("dataset/complaint_box.csv", mode='a', header=False, index=False)
