# geobot

## Phase 1

https://docs.google.com/document/d/1OsdqAObAYoUxHbK5OKSSR5EN6MoR-GGfxokp3sDve2Y/edit?usp=sharing
